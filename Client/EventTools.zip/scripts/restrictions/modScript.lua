extensions.load('restrictions')
setExtensionUnloadMode('restrictions', "manual")